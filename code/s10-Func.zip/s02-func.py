# -*- coding: utf-8 -*-

# 함수

# 함수호출    
# 함수가 정의되기 전에 호출되면 오류
# NameError: name 'open_account' is not defined
# open_account()    

# 함수정의
def open_account():
    print("새로운 계좌를 개설합니다.")
    

# 함수호출    
open_account()    
open_account()    
open_account()    
open_account()    
