# -*- coding: utf-8 -*-

# 예외처리
# 예외 발생시키기 : raise

# 새(bird)
# pass : 아무 처리를 하지 않음
class Bird:
    def fly(self): # 날다
        pass
    
bird = Bird()
bird.fly()    